namespace AntivirusApp.Models;

/// <summary>
/// Opciones del motor heurístico.
/// El parámetro se llama <c>IncludeHidden</c> en mayúscula a propósito:
/// ScanPage lo invoca con argumento con nombre <c>new ScanOptions(ScanMode.Folder, IncludeHidden: true)</c>.
/// </summary>
public sealed class ScanOptions
{
    public ScanOptions(ScanMode mode)
        : this(mode, false)
    {
    }

    public ScanOptions(ScanMode mode, bool IncludeHidden)
    {
        Mode = mode;
        this.IncludeHidden = IncludeHidden;
    }

    public ScanMode Mode { get; }

    /// <summary>Si se incluyen archivos ocultos y de sistema.</summary>
    public bool IncludeHidden { get; }

    /// <summary>Bytes máximos que se leen de cada archivo.</summary>
    public long MaxBytes => Mode switch
    {
        ScanMode.Quick => 512L * 1024,
        ScanMode.Folder => 2L * 1024 * 1024,
        ScanMode.Deep => 16L * 1024 * 1024,
        _ => 4L * 1024 * 1024
    };

    /// <summary>Puntuación a partir de la cual la muestra es maliciosa.</summary>
    public int MaliciousThreshold => 70;

    /// <summary>Puntuación a partir de la cual la muestra es sospechosa.</summary>
    public int SuspiciousThreshold => 35;
}

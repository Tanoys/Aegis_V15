namespace AntivirusApp.Models;

/// <summary>Profundidad y propósito del análisis.</summary>
public enum ScanMode
{
    /// <summary>Se adapta al tamaño del archivo.</summary>
    Automatic,

    /// <summary>Solo cabecera y firmas: rápido.</summary>
    Quick,

    /// <summary>Carpeta completa: enumeración recursiva y lectura ligera.</summary>
    Folder,

    /// <summary>Lectura profunda del contenido (hasta 16 MB por archivo).</summary>
    Deep
}

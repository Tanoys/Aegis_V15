using AntivirusApp.Services;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.System;

namespace AntivirusApp.Views;

public sealed partial class LoginPage : Page
{
    public LoginPage() => InitializeComponent();

    private void Login_Click(object sender, RoutedEventArgs e) => TryLogin();

    private void Pass_KeyDown(object sender, Microsoft.UI.Xaml.Input.KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.Enter) TryLogin();
    }

    private void TryLogin()
    {
        if (AuthService.Validate(UserBox.Text.Trim(), PassBox.Password))
        {
            Frame.Navigate(typeof(ShellPage));
            return;
        }

        ErrorText.Text = "Usuario o contraseña incorrectos";
        ErrorText.Visibility = Visibility.Visible;
    }
}

# Aegis · Endpoint Suite — proyecto completo

Proyecto WinUI 3 (.NET 8) montado sobre el **ZIP de Google Drive** (csproj, manifiestos,
assets y perfiles de publicación) + **los 12 archivos que pegaste** + los 8 que faltaban.

Namespace y ensamblado: **`AntivirusApp`**.

---

## 1. Credenciales de la pantalla de login

```
usuario:     admin
contraseña:  aegis
```

Se cambian creando `%LocalAppData%\Aegis\auth.json`:

```json
{ "user": "miUsuario", "sha256": "hash_sha256_de_la_contraseña_en_hex" }
```

`AuthService` no guarda la contraseña en claro y compara en tiempo fijo.

---

## 2. Archivos que pegaste (sin tocar su lógica)

| Archivo | Líneas |
|---|---|
| `App.xaml` | 104 |
| `App.xaml.cs` | 18 |
| `Services/NotificationService.cs` | 48 |
| `Views/ViewItems.cs` | 94 |
| `Views/LoginPage.xaml(.cs)` | 87 + 30 |
| `Views/ShellPage.xaml(.cs)` | 182 + 258 |
| `Views/ScanPage.xaml(.cs)` | 202 + 425 |
| `Views/LivePage.xaml(.cs)` | 152 + 180 |

## 3. Archivos que faltaban (escritos aquí, con las firmas exactas que usan los tuyos)

| Archivo | Contrato que respeta |
|---|---|
| `Models/Verdicts.cs` | `const string` `Malicious="M"`, `Suspicious="S"`, `Clean="C"`, `Error="E"` (los chips filtran por "M"/"S") |
| `Models/ScanMode.cs` | `Automatic`, `Quick`, `Folder`, `Deep` |
| `Models/ScanOptions.cs` | `new ScanOptions(ScanMode.Quick)` y `new ScanOptions(ScanMode.Folder, IncludeHidden: true)` |
| `Models/ScanResult.cs` | `Verdict`, `RiskScore`, `Reasons`, `Sha256`, `Size`, `Elapsed`, `IsError` — con `set` público (con `init` el build falla con CS8852 en `XamlTypeInfo.g.cs`) |
| `Engine/HeuristicScanner.cs` | `SafeScan(path, options, progress)`; acepta archivo o carpeta |
| `Engine/FileEnumerator.cs` | `Enumerate(folder, options, ct)` — lo usa `ScanPage.ScanFolderAsync` |
| `Engine/FolderWatcher.cs` | `new FolderWatcher(ruta)`, `FileDetected`, `WaitUntilReadyAsync` |
| `Engine/Ring.cs` | `Ring.Set(Ellipse, double)` mediante `StrokeDashArray` sobre la elipse rotada −90° |
| `Services/AuthService.cs` | `AuthService.Validate(usuario, contraseña)` |
| `MainWindow.xaml(.cs)` | `new MainWindow()` de `App.OnLaunched`: hospeda el `Frame` y navega a `LoginPage` |

## 4. Errores corregidos en tu código

Detectados compilando con Roslyn contra los ensamblados reales de WinUI:

| Error | Archivo | Causa | Corrección |
|---|---|---|---|
| `CS0103: FileEnumerator no existe` | `ScanPage.xaml.cs:101` | se usaba un tipo que no venía en el pegado | creado `Engine/FileEnumerator.cs` |
| `CS0428: método 'Count' como int` | `ScanPage.xaml.cs:102` | consecuencia del anterior (`ToList()` sobre un grupo de métodos) | resuelto al existir `FileEnumerator` |
| `CS0165: 'card' sin asignar` | `ShellPage.xaml.cs:195` | los botones de la tarjeta llamaban a `Close()`, que captura `card` y `timer` declarados más abajo | `Action dismiss` declarado antes y asignado al final; las 4 llamadas usan `dismiss()` |
| `CS0165: 'timer' sin asignar` | `ShellPage.xaml.cs:195` | ídem | ídem |

### Y dos del compilador de XAML

| Error | Archivo | Causa | Corrección |
|---|---|---|---|
| `WMC0001: Unknown type 'UniformGrid'` | `Views/LivePage.xaml:83` | `UniformGrid` **no existe en WinUI 3**: es un control de WPF (en WinUI viene en CommunityToolkit, no en el SDK) | sustituido por un `Grid` con 4 columnas `*` y `ColumnSpacing="12"`; cada tarjeta lleva su `Grid.Column` |
| `WMC0001: Unknown type 'UniformGrid'` | `Views/ScanPage.xaml:123` | ídem | ídem con `ColumnSpacing="24"` (los contadores del panel de análisis) |

### Y un crash en tiempo de ejecución

| Error | Causa | Corrección |
|---|---|---|
| `COMException: No COM servers are registered for this app` en `OnLaunched` | `AppNotificationManager.Default.Register()` necesita **identidad de paquete (MSIX)**. Ejecutando el `.exe` suelto o la configuración «sin empaquetar» de VS no existe el servidor COM de activación y la excepción no estaba capturada | `Register()` ahora prueba y, si falla, marca `ToastAvailable = false` y deja el aviso dentro de la ventana; el motivo se escribe en `%LocalAppData%\Aegis\app.log` |

### Diagnóstico de arranque (v5)

Ante un cierre silencioso con `0x80008089` (sin traza en el depurador), el arranque queda
instrumentado:

| Dónde | Qué hace |
|---|---|
| `App.App()` | suscribe `UnhandledException` y `AppDomain.UnhandledException`, y registra «App creada» |
| `App.OnLaunched()` | registra cada paso: notificaciones → `MainWindow` → `Activate`; si algo falla escribe el log y muestra un `MessageBox` nativo |
| `MainWindow` | la navegación a `LoginPage` pasa del constructor al evento `Loaded`, con `try/catch` y log |
| Log | `%LocalAppData%\Aegis\app.log` con fecha, paso, tipo de excepción, mensaje y `StackTrace` |

Con esto, cualquier fallo de arranque deja rastro en disco y en pantalla en lugar de
cerrar la app sin explicación.

### v8 — por qué «no aparecía nada»

| Causa | Corrección |
|---|---|
| `ScanPage.Record()` hacía `if (!item.IsAlert) return;`: los archivos limpios **no se listaban nunca**, así que parecía que no analizaba | ahora se listan **todos** los archivos analizados, con veredicto y puntuación; las alertas siguen disparando notificación |
| Los tres handlers (`ScanFile`, `ScanFolder`, `ScanZip`) eran `async void` con `try/finally` y **sin `catch`**: cualquier excepción (picker, permisos, ZIP dañado) desaparecía sin mensaje | añadido `catch` que escribe en `app.log` y muestra el error en `HeadTitle`/`HeadDetail` |
| No había forma de saber si se estaba ejecutando el build nuevo | el título de la ventana muestra **«motor 2.0»** y cada análisis se registra en `%LocalAppData%\Aegis\app.log` |

### Motor 2.0 — análisis estructural (v7)

El motor ya no solo mira bytes y cadenas: ahora entiende el formato.

| Inspector | Qué analiza | Ejemplos de indicios |
|---|---|---|
| `Engine/PeInspector.cs` | Cabecera PE, secciones, **tabla de importaciones**, overlay, entry point | `VirtualAllocEx` + `WriteProcessMemory` + `CreateRemoteThread` (inyección), `SetWindowsHookEx` (keylogger), `IsDebuggerPresent` (anti-debug), `URLDownloadToFile` (descarga), `CryptEncrypt` (ransomware), secciones `UPX0/Themida/.vmp0`, sección RWX, entropía ≥ 7,9 |
| `Engine/DocumentInspector.cs` | PDF, Office OOXML y accesos directos `.lnk` | `/JavaScript`, `/OpenAction`, `/Launch`; `word/vbaProject.bin` con `AutoOpen` + `CreateObject("WScript.Shell")`; `.lnk` con `powershell -enc` |
| `Engine/ArchiveInspector.cs` | ZIP sin extraer | entradas con `../` (zip slip), ejecutables dentro, bomba de descompresión, > 2 GB descomprimidos |

Resultados medidos con el proyecto compilado y muestras reales:

| Muestra | Veredicto | Score | Por qué |
|---|---|---|---|
| `7zr.exe` (binario legítimo real) | Limpio | 12 | 6 secciones, 133 imports, sin packer → **sin falso positivo** |
| `documento.exe` (texto renombrado) | Sospechoso | 38 | extensión ejecutable sin cabecera `MZ` |
| `eicar.txt` (firma de prueba) | Malicioso | 100 | firma EICAR dentro de un `.txt` |
| `presupuesto.pdf` con JS | Sospechoso | 50 | JavaScript + acción al abrir |
| `factura.lnk` → powershell -enc | Sospechoso | 67 | destino y argumentos de intérprete |
| `adjuntos.zip` con `../../evil.exe` | Sospechoso | 39 | zip slip + ejecutable dentro |
| `informe.docm` con macro AutoOpen | Sospechoso | 65 | macro con ejecución de comandos |
| PE con `VirtualAllocEx`+`WriteProcessMemory`+`CreateRemoteThread` | Malicioso | 73 | inyección de código en otro proceso |

### Motor: reglas anteriores (v6)

Detectado con pruebas reales: un `.txt` renombrado a `.exe` puntuaba **8/100** y se
marcaba «Limpio», así que nunca aparecía en la lista (la vista solo muestra alertas).

| Regla nueva | Puntos |
|---|---|
| Extensión ejecutable (`.exe`, `.dll`, `.scr`, `.com`…) sin cabecera `MZ` → archivo renombrado o dañado | +30 |
| Aviso «Análisis parcial: X MB revisados de Y MB» cuando el archivo supera el límite de lectura | informativo |

Resultados medidos tras el cambio:

| Muestra | Veredicto | Score |
|---|---|---|
| `documento.exe` (texto renombrado) | Sospechoso | 38 |
| `documento.txt.exe` | Sospechoso | 63 |
| `eicar.com` | Malicioso | 100 |
| `factura.pdf` con cabecera `MZ` | Sospechoso | 35 |
| `instalar.ps1` ofuscado | Sospechoso | 42 |

Umbrales: **≥ 35 sospechoso**, **≥ 70 malicioso** (`Models/ScanOptions.cs`).

Ningún cambio toca el diseño ni la lógica: el `Grid` de 4 columnas iguales reproduce el
reparto del `UniformGrid`, y la captura de `card`/`timer` se movió a una variable ya
inicializada.

## 5. Verificación hecha antes de entregar

| Comprobación | Resultado |
|---|---|
| Compilación C# (Roslyn, 16 archivos, refs reales WinUI 2.3.9 / SDK.NET 10.0.19041) | **0 errores** |
| Propiedades y eventos del XAML contra los metadatos de WinUI | **806 / 806 existen** |
| Tipos de control usados en el XAML | los 29 existen en WinUI 3 (ya sin `UniformGrid`) |
| Claves `{StaticResource ...}` frente a `App.xaml` | todas definidas (22) |
| `x:Bind` de las plantillas frente a `ScanItem` | todas resuelven |
| `x:Class` ↔ code-behind y `x:Name` duplicados | correctos en los 6 XAML |
| Firmas de los 19 handlers | todas coinciden con su `EventArgs` |
| `dotnet restore` de los paquetes 2.5.1 | correcto |

**No verificado** (necesita Windows): el paso del compilador de XAML (`.g.cs`), el
empaquetado MSIX y la ejecución.

## 6. Compilar

```powershell
dotnet build AntivirusApp.csproj -c Debug -p:Platform=x64
```

Abre `AntivirusApp.slnx` (VS 17.10+) o `AntivirusApp.sln` (cualquier VS 2022). Si algo
falla, genera el binlog y pásalo:

```powershell
dotnet build AntivirusApp.csproj -c Debug -p:Platform=x64 -bl:build.binlog
```

---

## v9 — Clenaer (nuevo módulo)

Se añade el **Clenaer** al menú lateral, entre *Análisis manual* y *Vigilancia en vivo*.
No se ha tocado ninguna línea de los módulos anteriores: el botón nuevo navega a
`CleanerPage` con el mismo `Navigate(...)` y el mismo `Mark(...)` de resaltado.

| Archivo nuevo | Qué contiene |
|---|---|
| `Views/CleanerPage.xaml` | Interfaz: tarjeta de unidades y opciones, progreso, filtros y lista |
| `Views/CleanerPage.xaml.cs` | Lógica de la vista (escaneo en segundo plano, orden, selección, papelera) |
| `Views/CleanerRow.cs` | Fila de la lista (sirve para archivos, carpetas y aplicaciones) |
| `Models/CleanerModels.cs` | `CleanerOptions`, `CleanerCounters`, `CleanerItem`, `AppUsage`, `TrashResult` |
| `Services/CleanerService.cs` | Motor: `Scan`, `MeasureApps`, `MoveToTrash`, `Reveal`, `DefaultRoots` |

| Archivo modificado | Cambio |
|---|---|
| `Views/ShellPage.xaml` | Botón `NavCleaner` («Clenaer», glifo de papelera) + pie «Motor heurístico 2.0 · Clenaer» |
| `Views/ShellPage.xaml.cs` | `NavCleaner_Click` y `Mark(NavCleaner, …)` en `Navigate` |

### Dos modos

1. **Archivos / Carpetas pesadas** — recorre las unidades con `DirectoryInfo` en un hilo
   de fondo (la UI nunca se bloquea) y devuelve lo que supera el mínimo elegido.
   Casilla **«Evitar carpetas de sistema»** activada por defecto: no entra en `Windows`,
   `System32`, `WinSxS`, `$Recycle.Bin`, `System Volume Information`, `$Windows.~BT`…
   Ordenable por **peso, nombre, fecha y tipo**; buscador; selección múltiple.
2. **Por aplicación** — mide cada carpeta de programa (`Program Files`, `Program Files (x86)`,
   `LocalAppData`, `Roaming`, `ProgramData`, Descargas, Documentos, Escritorio, Vídeos)
   y lista **peso, nº de archivos y última actividad**.

### Borrado

`SHFileOperationW` con `FOF_ALLOWUNDO` → **Papelera de reciclaje real de Windows**, sin
dependencias NuGet ni referencias a `Microsoft.VisualBasic`. Antes hay un `ContentDialog`
con la lista de elementos, el total a liberar y una casilla que hay que marcar para que
el botón se habilite. Lo que está en uso o sin permisos se informa y **no se borra**.

### Rendimiento

Un solo hilo para el escaneo, `Parallel.ForEach` (núcleos/2) para medir aplicaciones y un
`DispatcherQueueTimer` de 150 ms que refresca contadores: la ventana sigue respondiendo
incluso recorriendo un disco entero.

---

# v10 — «Espacio y ZIP» + gráficas en el Clenaer

Se añade un módulo nuevo de **análisis de espacio con gráficas** y un botón de
**comprimir carpetas a ZIP**. No se reescribe nada del motor ni de las pantallas
existentes: el Clenaer gana una franja de gráficas y el menú lateral gana un módulo.

| Archivo nuevo | Qué contiene |
|---|---|
| `Controls/Charts.cs` | Gráficas sin dependencias: barras proporcionales, dona hueca con arcos y leyenda |
| `Models/SpaceModels.cs` | `FolderUsage`, `KindUsage`, `SpaceReport`, `SpaceCounters`, `ZipOutcome` |
| `Services/SpaceService.cs` | `Scan` (mide carpetas y tipos), `Compress` (ZIP + verificación + borrado), `IsProtected` |
| `Views/SpaceRow.cs` | `RootOption` (raíz del desplegable) y `SpaceRow` (fila de la tabla) |
| `Views/SpacePage.xaml` | Interfaz: barra de análisis, 4 indicadores, 2 gráficas y tabla de carpetas |
| `Views/SpacePage.xaml.cs` | Lógica: análisis en segundo plano, selección, confirmación y compresión |

| Archivo modificado | Cambio |
|---|---|
| `Views/ShellPage.xaml` | Botón `NavSpace` («Espacio y ZIP», glifo `E7B8`) |
| `Views/ShellPage.xaml.cs` | `NavSpace_Click` y `Mark(NavSpace, …)` |
| `Views/CleanerPage.xaml` | Franja de análisis dentro de la tarjeta de estado: `MiniBars`, `MiniDonut`, `MiniLegend` |
| `Views/CleanerPage.xaml.cs` | `DrawAnalysis()`, llamado al final de `Rebuild()` |

## Qué se ve en «Espacio y ZIP»

1. **Barra de análisis** — desplegable con todas las unidades fijas/extraíbles y las
   carpetas del usuario (perfil, Vídeos, Imágenes, Música, Documentos), botón
   *Analizar espacio*, *Detener* y *Mis ZIP*.
2. **Cuatro indicadores** — espacio analizado, archivos, carpetas candidatas y
   seleccionado (se actualiza al marcar filas).
3. **Gráficas**
   - *Dónde se va el espacio*: barras con las 8 carpetas más pesadas de la raíz.
   - *Por tipo de archivo*: dona con el reparto por categoría (vídeo, imagen, audio,
     documento, comprimido, instalador, código, base de datos, caché, otro) + leyenda
     con tamaño y porcentaje.
   - Cada fila de la tabla lleva además una mini-barra con su porcentaje del total.
4. **Tabla de carpetas** — nombre, nº de archivos, % del total, tamaño y botón
   *Dentro* para volver a medir esa subcarpeta (análisis en profundidad).
5. **Acciones** — *Solo comprimir* y *Comprimir y borrar original*.

## Cómo funciona la compresión

1. Se pide confirmación con la lista de carpetas, el total y la ruta de destino.
   Para borrar hay que marcar la casilla *«Entiendo que la carpeta original se borrará»*;
   sin marcarla, el botón principal está deshabilitado.
2. El ZIP se crea con `ZipFile.CreateFromDirectory` en
   `%LocalAppData%\Aegis\archives\<carpeta>-AAAAMMDD-HHMMSS.zip`.
3. **Verificación obligatoria**: se abre el ZIP, se cuentan las entradas y se suma su
   tamaño. Si el número de archivos no coincide o falta más de un 0,5 % del peso, se
   **borra el ZIP** y la carpeta original **no se toca**.
4. Sólo entonces se borra la carpeta original (`Directory.Delete(..., true)`) y se
   informa de lo liberado. Si el borrado falla (archivo en uso), el ZIP queda y se
   avisa: nunca se pierde información.

## Seguridad: qué nunca se toca

`SpaceService.IsProtected` bloquea, tanto en la interfaz (candado + selección inválida)
como en el servicio (segunda comprobación antes de comprimir):

- Raíces de unidad (`C:\`), `Windows`, `System32`, `SysWOW64`, `WinSxS`,
  `Program Files`, `Program Files (x86)`, `ProgramData`, `Recovery`, `Boot`, `PerfLogs`;
- la carpeta del perfil de usuario **entera** (sí se pueden comprimir sus subcarpetas
  como `Downloads`, `Videos`, etc.);
- cualquier carpeta que contenga el directorio de ZIPs.

## Rendimiento

- `EnumerationOptions` con `IgnoreInaccessible = true` y
  `AttributesToSkip = ReparsePoint`: no sigue enlaces ni se atasca en carpetas
  protegidas del sistema (evita bucles y excepciones por acceso denegado).
- El análisis corre en `Task.Run` con `CancellationToken` y publica progreso cada
  120 ms mediante `DispatcherQueueTimer`; la ventana nunca se congela.
- La compresión se ejecuta de una carpeta en una (`await` secuencial) para no saturar
  el disco con varios ZIP a la vez.

## Nota de diseño

Las gráficas están hechas con formas nativas (`Border` + columnas «star» para las barras,
`PathGeometry`/`ArcSegment` para la dona). No hace falta añadir Win2D, LiveCharts ni
ningún paquete: el `.csproj` no cambia.

---

# v11 — corrección del crash al abrir el Clenaer

**Síntoma**: al pulsar «Clenaer» la app moría con
`XamlParseException ... Object reference not set to an instance of an object`
seguido de `NullReferenceException` y código de salida `0xFFFFFFFF`.

**Causa**: la franja de gráficas de la v10 se añadió como XAML dentro de
`CleanerPage.xaml`, e introducía dos tipos de elemento que **no aparecían en ningún
otro XAML del proyecto** (`Rectangle` y `Canvas` anidado en una celda `Auto`). En la
práctica, `InitializeComponent()` lanzaba la excepción durante el parseo, así que
ningún `x:Name` llegaba a asignarse (de ahí los `RowList fue null`).

**Solución en la v11**:

1. `CleanerPage.xaml` vuelve a ser **idéntico al de la v9**, con una única diferencia:
   `<StackPanel x:Name="StatsStack">`. Ningún elemento nuevo, ninguna gráfica en XAML.
2. La franja de análisis (divisor + rejilla de 3 columnas + dona + leyenda) se
   **construye en código** en `BuildAnalysisBlock()`, justo después de
   `InitializeComponent()`, y `DrawAnalysis()` sólo rellena los hosts ya creados
   (con guardas `is null` y `try/catch` que escriben en `app.log`).
3. `SpacePage.xaml` pierde el `LinearGradientBrush` (único elemento nuevo que quedaba
   en el proyecto); la tarjeta destacada usa un color plano `#FF1B2B4A`.
4. **Diagnóstico nuevo**: `ShellPage` engancha `ContentFrame.NavigationFailed`. Si
   cualquier página falla al construirse, la app **ya no se cierra**: escribe el error
   completo (excepción + internas + primera línea de stack que apunte a `AntivirusApp`)
   en `%LocalAppData%\Aegis\app.log` y lo muestra en un diálogo.

Si vuelve a fallar algo, ahora hay dos fuentes de verdad: el diálogo en pantalla y
las últimas líneas de `app.log`.

**Importante al recompilar**: borra `bin` y `obj` antes de compilar. Un `obj` viejo
puede reutilizar el `CleanerPage.g.cs` generado con el XAML anterior y reproducir
errores que ya no existen en el código fuente.

---

# v12 — causa real del crash del Clenaer (corregida)

El diálogo de error de la v11 dio el stack exacto:

```
CleanerPage.UpdateSelection()      ← RowList.SelectedItems
CleanerPage.Rebuild()
CleanerPage.Sort_Changed(sender, SelectionChangedEventArgs)
WinRT.EventSource…SelectionChangedEventHandler
Microsoft.UI.Xaml.Controls.Frame.Navigate(…)
ShellPage.Navigate(…) → NavCleaner_Click
```

**Diagnóstico definitivo**: `SortBox` tiene `SelectedIndex="0"` en el XAML. WinUI aplica
ese valor **durante** `InitializeComponent()`, y eso dispara `SelectionChanged` →
`Sort_Changed` → `Rebuild()` → `UpdateSelection()`. En ese instante `RowList` **todavía
no existe**, porque en el archivo XAML está declarado *después* del `SortBox` (los
`x:Name` se asignan en orden de documento). Resultado: `NullReferenceException`, que
WinUI envuelve y reporta como `XamlParseException: XAML parsing failed`.

Era un fallo latente del Clenaer v9, no de las gráficas: sólo se manifiesta al abrir
la página, y siempre.

**Corrección (v12)**:

| Archivo | Cambio |
|---|---|
| `Views/CleanerPage.xaml.cs` | Campo `_ready` (false durante `InitializeComponent`), activado justo antes del `Rebuild()` inicial. `Rebuild()` y `UpdateSelection()` salen sin hacer nada si `_ready` es false o si sus controles aún son null. |
| `Views/SpacePage.xaml.cs` | Misma bandera; `Root_Changed` la respeta. |

Con esto, el evento que se dispara durante el parseo ya no toca controles inexistentes,
y la página se pinta al final del constructor, cuando todo existe.

Regla general aplicada al resto de la app: **ningún handler enganchado en XAML debe
asumir que los controles declarados más abajo existen**. Los que dependen de índices
iniciales (`SelectedIndex`, `SelectedItem`, `Text`) van guardados.

---

# v13 — Aegiss_Clenaer y Aegiss_TheClurer (rediseño pedido)

## Aegiss_Clenaer (antes «Clenaer»)

- **Una sola acción**: botón grande «Escanear equipo completo» (unidades fijas del equipo).
- Resultado en tres bloques:
  1. **Indicadores**: archivos revisados, carpetas revisadas, peso encontrado.
  2. **Gráfica TOP**: las 8 entradas más pesadas de la pestaña activa.
  3. **Lista separada** con dos pestañas: **Archivos** y **Carpetas**. Cada fila
     muestra el nombre, el origen (carpeta contenedora / ruta), el peso y dos botones:
     **Mostrar carpeta** y **Eliminar**.
- **Al eliminar** aparece un aviso de peligro con el elemento seleccionado y su peso,
  y una casilla obligatoria *«Confirmo que no lo voy a utilizar»*: el botón «Eliminar»
  está deshabilitado hasta marcarla. Con «Cancelar» no se toca nada.
  El borrado va a la **Papelera de reciclaje** (recuperable), no a la nada.

## Aegiss_TheClurer (antes «Espacio y ZIP»)

- **Aplicaciones del sistema**: botón «Medir aplicaciones».
  - El peso se muestra como **mapa de cuadrados**: cada app es un rectángulo
    proporcional a su tamaño (grande si pesa mucho, pequeño si pesa poco).
  - Debajo, lista de apps con grupo, nº de archivos, ruta y **Mostrar carpeta**.
- **Carpetas → ZIP**: botón «Analizar carpetas para ZIP» y, por cada carpeta,
  **Comprimir** o **Comprimir y borrar** (con casilla de confirmación; el ZIP se
  verifica antes de borrar nada, como en la v10).
- Botón **Mis ZIP** para abrir `%LocalAppData%\Aegis\archives`.

## Desplazamiento

- Las dos páginas tienen **barra de desplazamiento vertical** en toda la página y
  **barra visible** en cada lista interna (resultados, apps, carpetas).
- La lista de resultados de **Análisis manual** también muestra ya su barra
  (`ScrollViewer.VerticalScrollBarVisibility="Visible"`).

## Sin handlers en XAML

Las dos páginas nuevas cablean **todos** los eventos en el constructor, y las filas se
construyen en código. Así desaparece por completo la clase de fallo de la v12 (un
handler que se dispara a mitad del parseo y toca controles que aún no existen).

---

# v14 — cuadros acomodados y selector de carpeta

## Aegiss_Clenaer

- **Cuadros igualados**: la fila de indicadores tiene altura fija (96 px), el mismo
  padding y tres líneas por cuadro (título, número, aclaración). Ya no bailan de alto
  ni de posición.
- **Nuevo cuadro «O analiza una carpeta concreta»**, justo debajo de los indicadores:
  · `Elegir carpeta…` → `FolderPicker` nativo de Windows (con `InitializeWithWindow`,
    imprescindible en WinUI 3 dentro de un `Frame`).
  · El cuadro muestra la ruta elegida y `Analizar esta carpeta` se habilita al elegirla.
  · Analiza **solo esa carpeta**; el resto del equipo no se toca.
- La cabecera conserva `Escanear equipo completo` (todas las unidades fijas) + `Detener`.

## Aegiss_TheClurer

- **Cuadros igualados**: fila de 4 indicadores con la misma altura y estructura que en
  Clenaer (aplicaciones · peso de apps · carpetas · peso en carpetas).
- **Las dos acciones son ahora cuadros** (dos tarjetas del mismo tamaño):
  1. *Aplicaciones del sistema* → `Medir aplicaciones`.
  2. *Carpetas a ZIP* → muestra la carpeta objetivo, `Cambiar carpeta…`,
     `Analizar carpetas`, `Mis ZIP`.
- Se mantiene el **mapa de cuadrados** para el peso de las apps y las listas debajo.

Verificado: 30/30 `.cs` sin errores de sintaxis, 8/8 XAML válidos, sin handlers en XAML
en las dos páginas (todo cableado en el constructor).

---

# v15 — mínimos documentados, mapa de ZIP y limpieza de botones

## Aegiss_Clenaer · aclaración del mínimo

Se añade el cuadro **«QUÉ SE MIDE»**, justo encima de la gráfica, que lo dice sin
ambigüedad:

> Solo se miden los elementos grandes: archivos de 20 MB o más y carpetas de 60 MB o
> más. **Todo lo que esté por debajo de ese mínimo NO se mide ni aparece en la lista**,
> porque libera muy poco espacio.

Y al lado, el interruptor **«Incluir pequeños»**:

| Estado | Qué mide |
|---|---|
| **Solo grandes** (por defecto) | archivos ≥ 20 MB · carpetas ≥ 60 MB · hasta 800 archivos |
| **Incluir pequeños** | archivos ≥ 1 MB · carpetas ≥ 5 MB · hasta 2.000 archivos |

Al cambiar el interruptor se repite automáticamente el último escaneo con el nuevo
filtro (no hay que volver a pulsar el botón). El texto del cuadro se actualiza solo.
Mientras se escanea, el interruptor queda bloqueado.

## Aegiss_TheClurer · mapa de cuadrados para ZIP

Faltaba la ilustración de cuadrados en la parte de ZIP: solo había lista. Ahora hay
**dos mapas**:

1. **Aplicaciones · cuánto pesan** (ya existía).
2. **Carpetas pesadas · cuánto pesan** (nuevo): un cuadrado por carpeta, proporcional
   a su tamaño, justo encima de la lista de carpetas que se pueden comprimir.

## Botones retirados

- Fuera el botón **«Mis ZIP»**.
- Fuera el cuadro del encabezado con la ruta **`%LocalAppData%\Aegis\archives`**.

Los ZIP se siguen creando en esa ruta (aparece en el diálogo de confirmación de cada
compresión), pero ya no ocupa espacio en la interfaz.

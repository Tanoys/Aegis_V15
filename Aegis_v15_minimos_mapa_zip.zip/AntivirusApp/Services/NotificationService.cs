using System;
using System.IO;
using System.Text;
using AntivirusApp.Models;
using AntivirusApp.Views;
using Microsoft.Windows.AppNotifications;
using Microsoft.Windows.AppNotifications.Builder;

namespace AntivirusApp.Services;

public sealed record AlertMessage(string Glyph, string Kind, string Title, string Body, string AccentKey, ScanItem? Item);

public static class NotificationService
{
    private static bool _initialized;

    /// <summary>
    /// True si los toasts nativos están disponibles. Requiere que la app se
    /// ejecute con identidad de paquete (MSIX). En ejecución sin empaquetar
    /// Windows no tiene registrado el servidor COM de activación y
    /// <c>Register()</c> lanza COMException "No COM servers are registered for this app",
    /// así que se degrada a notificaciones dentro de la ventana.
    /// </summary>
    public static bool ToastAvailable { get; private set; }

    public static event Action<AlertMessage>? InApp;

    /// <summary>Nunca lanza: si no hay identidad de paquete, sigue la app.</summary>
    public static void Register()
    {
        if (_initialized)
        {
            return;
        }

        _initialized = true;

        try
        {
            AppNotificationManager.Default.Register();
            ToastAvailable = true;
        }
        catch (Exception ex)
        {
            ToastAvailable = false;
            Log("Toast no disponible (se usará el aviso interno): " + ex.Message);
        }
    }

    public static void Alert(ScanItem item)
    {
        bool malicious = item.Verdict == Verdicts.Malicious;
        Notify(new AlertMessage(
            Palette.GlyphFor(item.Verdict),
            malicious ? "Amenaza probable" : "Archivo sospechoso",
            item.Name,
            $"Riesgo {item.Result.RiskScore} de 100. {item.Origin}",
            Palette.KeyFor(item.Verdict),
            item));
    }

    public static void Summary(string glyph, string kind, string title, string body, string accentKey) =>
        Notify(new AlertMessage(glyph, kind, title, body, accentKey, null));

    public static void Notify(AlertMessage message)
    {
        if (ToastAvailable)
        {
            try
            {
                var toast = new AppNotificationBuilder()
                    .AddText(message.Title)
                    .AddText(message.Body)
                    .BuildNotification();

                AppNotificationManager.Default.Show(toast);
            }
            catch (Exception ex)
            {
                ToastAvailable = false;
                Log("Fallo mostrando el toast: " + ex.Message);
            }
        }

        InApp?.Invoke(message);
    }

    /// <summary>Diagnóstico mínimo en %LocalAppData%\Aegis\app.log.</summary>
    private static void Log(string message)
    {
        try
        {
            string folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Aegis");

            Directory.CreateDirectory(folder);

            File.AppendAllText(
                Path.Combine(folder, "app.log"),
                $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} {message}{Environment.NewLine}",
                Encoding.UTF8);
        }
        catch (Exception)
        {
            // Un fallo al registrar el diagnóstico no debe romper nada.
        }
    }
}

using System;
using AntivirusApp.Views;
using Microsoft.UI.Xaml;

namespace AntivirusApp;

/// <summary>
/// Ventana principal: hospeda el Frame de navegación.
/// La navegación a LoginPage se hace en Loaded (no en el constructor) para que
/// el árbol visual ya exista; cualquier fallo queda registrado en app.log.
/// </summary>
public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        Title = $"Aegis · Endpoint Suite  ·  motor {AntivirusApp.Engine.HeuristicScanner.Version}";

        try
        {
            AppWindow.Resize(new Windows.Graphics.SizeInt32(1360, 880));
        }
        catch (Exception ex)
        {
            App.Log("Resize falló: " + ex.Message);
        }

        RootFrame.Loaded += RootFrame_Loaded;
    }

    private void RootFrame_Loaded(object sender, RoutedEventArgs e)
    {
        RootFrame.Loaded -= RootFrame_Loaded;

        try
        {
            App.Log("MainWindow: navegando a LoginPage");
            RootFrame.Navigate(typeof(LoginPage));
            App.Log("MainWindow: LoginPage cargada");
        }
        catch (Exception ex)
        {
            App.Log("MainWindow: fallo al navegar a LoginPage", ex);
            throw;
        }
    }
}
